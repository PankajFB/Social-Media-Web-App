import { useFirebase } from "@/Context/FirebaseContext";
import { onAuthStateChanged } from "firebase/auth";
import React, { useEffect } from "react";

const initAuth = () => {
  // use the firebase context
  const firebase = useFirebase();

  //  destructure the firebase context
  const { auth, singedInUser, setSingedInUser } = firebase || {};

  // to check if the user is logged in or not
//   useEffect(() => {
//     onAuthStateChanged(auth, (singedInUser) => {
//       if (singedInUser) {
//         console.log("User is signed in");
//         console.log(singedInUser.email);
//         setSingedInUser(singedInUser);
//       } else {
//         console.log("User is logged out");
//         setSingedInUser(null);
//       }
//     });
//   }, [auth, singedInUser, setSingedInUser]);
// };
}

export default initAuth;
