import "@/styles/globals.css";
import { FirebaseProvider } from "@/Context/FirebaseContext";
import Head from "next/head";
import { SocketProvider } from "@/Context/SocketContext";
import initAuth from "@/utils/initAuth";


export default function App({ Component, pageProps }) {

  initAuth();
  
  return (
    <>
      <Head>
        <title>Webapp</title>
       {/* it is not recommended to add the boostrap here that is why we have add boostrap link in the document page */}
      </Head>
     
      <FirebaseProvider>
        <SocketProvider>
          <Component {...pageProps} />
        </SocketProvider>
      </FirebaseProvider>
    </>
  );
}
