import React from "react";
import { io, Socket } from "socket.io-client";

export const SocketContext = React.createContext(null);

export const SocketProvider = (props) => {
  const socket = React.useMemo(() => {
    return io("http://localhost:4000");
  },[]);
  return (
    <SocketContext.Provider value={socket}>
      {props.children}
    </SocketContext.Provider>
  );
};
